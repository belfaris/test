<template>
  <v-main>
    <div class="fill-height d-flex flex-row align-center justify-center">
      <h1>Page not found :(</h1>
    </div>
  </v-main>
</template>

<script>
export default {
  name: "NotFound"
}
</script>
