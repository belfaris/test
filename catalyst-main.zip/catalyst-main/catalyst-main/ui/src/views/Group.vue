<template>
  <div></div>
</template>

<script>
export default {
  name: "Group"
}
</script>

<style scoped>

</style>
