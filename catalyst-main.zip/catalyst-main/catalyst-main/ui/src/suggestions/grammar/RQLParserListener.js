// Generated from CAQLParser.g4 by ANTLR 4.9.2
// jshint ignore: start
import antlr4 from 'antlr4';

// This class defines a complete listener for a parse tree produced by CAQLParser.
export default class CAQLParserListener extends antlr4.tree.ParseTreeListener {

	// Enter a parse tree produced by CAQLParser#parse.
	enterParse(ctx) {
	}

	// Exit a parse tree produced by CAQLParser#parse.
	exitParse(ctx) {
	}


	// Enter a parse tree produced by CAQLParser#expression.
	enterExpression(ctx) {
	}

	// Exit a parse tree produced by CAQLParser#expression.
	exitExpression(ctx) {
	}


	// Enter a parse tree produced by CAQLParser#operator_unary.
	enterOperator_unary(ctx) {
	}

	// Exit a parse tree produced by CAQLParser#operator_unary.
	exitOperator_unary(ctx) {
	}


	// Enter a parse tree produced by CAQLParser#reference.
	enterReference(ctx) {
	}

	// Exit a parse tree produced by CAQLParser#reference.
	exitReference(ctx) {
	}


	// Enter a parse tree produced by CAQLParser#compound_value.
	enterCompound_value(ctx) {
	}

	// Exit a parse tree produced by CAQLParser#compound_value.
	exitCompound_value(ctx) {
	}


	// Enter a parse tree produced by CAQLParser#function_call.
	enterFunction_call(ctx) {
	}

	// Exit a parse tree produced by CAQLParser#function_call.
	exitFunction_call(ctx) {
	}


	// Enter a parse tree produced by CAQLParser#value_literal.
	enterValue_literal(ctx) {
	}

	// Exit a parse tree produced by CAQLParser#value_literal.
	exitValue_literal(ctx) {
	}


	// Enter a parse tree produced by CAQLParser#array.
	enterArray(ctx) {
	}

	// Exit a parse tree produced by CAQLParser#array.
	exitArray(ctx) {
	}


	// Enter a parse tree produced by CAQLParser#object.
	enterObject(ctx) {
	}

	// Exit a parse tree produced by CAQLParser#object.
	exitObject(ctx) {
	}


	// Enter a parse tree produced by CAQLParser#object_element.
	enterObject_element(ctx) {
	}

	// Exit a parse tree produced by CAQLParser#object_element.
	exitObject_element(ctx) {
	}


	// Enter a parse tree produced by CAQLParser#object_element_name.
	enterObject_element_name(ctx) {
	}

	// Exit a parse tree produced by CAQLParser#object_element_name.
	exitObject_element_name(ctx) {
	}



}
