package service

import (
    "context"
    "encoding/json"
    "fmt"
    "io/ioutil"
    "os"
    "time"

    "github.com/SecurityBrewery/catalyst/database"
    "github.com/SecurityBrewery/catalyst/generated/model"
)

// GenerateReport generates a report after filling in all details in a ticket.
func GenerateReport(ticket *model.Ticket) error {
    // Marshal ticket data to JSON
    jsonData, err := json.Marshal(ticket)
    if err != nil {
        return fmt.Errorf("failed to marshal ticket data: %v", err)
    }

    // Define report filename based on ticket ID and current timestamp
    reportFilename := fmt.Sprintf("report_%s_%s.json", ticket.ID, time.Now().Format("20060102150405"))

    // Write JSON data to report file
    err = ioutil.WriteFile(reportFilename, jsonData, 0644)
    if err != nil {
        return fmt.Errorf("failed to write report file: %v", err)
    }

    fmt.Printf("Report generated successfully: %s\n", reportFilename)
    return nil
}
