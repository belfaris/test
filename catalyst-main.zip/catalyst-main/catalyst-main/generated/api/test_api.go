package api

import "time"

type Args struct {
	Method string
	URL    string
	Data   any
}
type Want struct {
	Status int
	Body   any
}

var Tests = []struct {
	Name string
	Args Args
	Want Want
}{

	{
		Name: "ListAutomations",
		Args: Args{Method: "Get", URL: "/automations"},
		Want: Want{
			Status: 200,
			Body:   []any{map[string]any{"id": "comment", "image": "docker.io/python:3", "script": "", "type": []any{"playbook"}}, map[string]any{"id": "hash.sha1", "image": "docker.io/python:3", "schema": "{\"title\":\"Input\",\"type\":\"object\",\"properties\":{\"default\":{\"type\":\"string\",\"title\":\"Value\"}},\"required\":[\"default\"]}", "script": "", "type": []any{"global", "artifact", "playbook"}}, map[string]any{"id": "vt.hash", "image": "docker.io/python:3", "schema": "{\"title\":\"Input\",\"type\":\"object\",\"properties\":{\"default\":{\"type\":\"string\",\"title\":\"Value\"}},\"required\":[\"default\"]}", "script": "", "type": []any{"global", "artifact", "playbook"}}},
		},
	},

	{
		Name: "CreateAutomation",
		Args: Args{Method: "Post", URL: "/automations", Data: map[string]any{"id": "hash-sha-256", "image": "docker.io/python:3", "script": "import sys\nimport json\nimport hashlib\n\n\ndef run(msg):\n    sha256 = hashlib.sha256(msg['payload']['default'].encode('utf-8'))\n    return {'hash': sha256.hexdigest()}\n\n\nprint(json.dumps(run(json.loads(sys.argv[1]))))\n", "type": []any{"global"}}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"id": "hash-sha-256", "image": "docker.io/python:3", "script": "import sys\nimport json\nimport hashlib\n\n\ndef run(msg):\n    sha256 = hashlib.sha256(msg['payload']['default'].encode('utf-8'))\n    return {'hash': sha256.hexdigest()}\n\n\nprint(json.dumps(run(json.loads(sys.argv[1]))))\n", "type": []any{"global"}},
		},
	},

	{
		Name: "GetAutomation",
		Args: Args{Method: "Get", URL: "/automations/hash.sha1"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"id": "hash.sha1", "image": "docker.io/python:3", "schema": "{\"title\":\"Input\",\"type\":\"object\",\"properties\":{\"default\":{\"type\":\"string\",\"title\":\"Value\"}},\"required\":[\"default\"]}", "script": "#!/usr/bin/env python\n\nimport sys\nimport json\nimport hashlib\n\n\ndef run(msg):\n    sha1 = hashlib.sha1(msg['payload']['default'].encode('utf-8'))\n    return {\"hash\": sha1.hexdigest()}\n\n\nprint(json.dumps(run(json.loads(sys.argv[1]))))\n", "type": []any{"global", "artifact", "playbook"}},
		},
	},

	{
		Name: "UpdateAutomation",
		Args: Args{Method: "Put", URL: "/automations/hash.sha1", Data: map[string]any{"id": "hash.sha1", "image": "docker.io/python:3", "script": "import sys\nimport json\nimport hashlib\n\n\ndef run(msg):\n    sha1 = hashlib.sha1(msg['payload'].encode('utf-8'))\n    return {'hash': sha1.hexdigest()}\n\n\nprint(json.dumps(run(json.loads(sys.argv[1]))))\n", "type": []any{"global", "artifact", "playbook"}}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"id": "hash.sha1", "image": "docker.io/python:3", "script": "import sys\nimport json\nimport hashlib\n\n\ndef run(msg):\n    sha1 = hashlib.sha1(msg['payload'].encode('utf-8'))\n    return {'hash': sha1.hexdigest()}\n\n\nprint(json.dumps(run(json.loads(sys.argv[1]))))\n", "type": []any{"global", "artifact", "playbook"}},
		},
	},

	{
		Name: "DeleteAutomation",
		Args: Args{Method: "Delete", URL: "/automations/hash.sha1"},
		Want: Want{
			Status: 204,
			Body:   nil,
		},
	},

	{
		Name: "CurrentUser",
		Args: Args{Method: "Get", URL: "/currentuser"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"apikey": false, "blocked": false, "id": "bob", "roles": []any{"admin"}},
		},
	},

	{
		Name: "CurrentUserData",
		Args: Args{Method: "Get", URL: "/currentuserdata"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"email": "bob@example.org", "id": "bob", "name": "Bob Bad"},
		},
	},

	{
		Name: "UpdateCurrentUserData",
		Args: Args{Method: "Put", URL: "/currentuserdata", Data: map[string]any{"email": "bob@example.org", "name": "Bob Bad"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"email": "bob@example.org", "id": "bob", "name": "Bob Bad"},
		},
	},

	{
		Name: "DashboardData",
		Args: Args{Method: "Get", URL: "/dashboard/data?aggregation=type&filter=status+%3D%3D+%22closed%22"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"alert": 2, "incident": 1},
		},
	},

	{
		Name: "ListDashboards",
		Args: Args{Method: "Get", URL: "/dashboards"},
		Want: Want{
			Status: 200,
			Body:   []any{map[string]any{"id": "simple", "name": "Simple", "widgets": []any{map[string]any{"aggregation": "owner", "filter": "status == \"open\"", "name": "open_tickets_per_user", "type": "bar", "width": 4}, map[string]any{"aggregation": "CONCAT(DATE_YEAR(created), \"-\", DATE_ISOWEEK(created) < 10 ? \"0\" : \"\", DATE_ISOWEEK(created))", "name": "tickets_per_week", "type": "line", "width": 8}}}},
		},
	},

	{
		Name: "CreateDashboard",
		Args: Args{Method: "Post", URL: "/dashboards", Data: map[string]any{"name": "My Dashboard", "widgets": []any{}}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"id": "my-dashboard", "name": "My Dashboard", "widgets": []any{}},
		},
	},

	{
		Name: "GetDashboard",
		Args: Args{Method: "Get", URL: "/dashboards/simple"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"id": "simple", "name": "Simple", "widgets": []any{map[string]any{"aggregation": "owner", "filter": "status == \"open\"", "name": "open_tickets_per_user", "type": "bar", "width": 4}, map[string]any{"aggregation": "CONCAT(DATE_YEAR(created), \"-\", DATE_ISOWEEK(created) < 10 ? \"0\" : \"\", DATE_ISOWEEK(created))", "name": "tickets_per_week", "type": "line", "width": 8}}},
		},
	},

	{
		Name: "UpdateDashboard",
		Args: Args{Method: "Put", URL: "/dashboards/simple", Data: map[string]any{"name": "Simple", "widgets": []any{}}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"id": "simple", "name": "Simple", "widgets": []any{}},
		},
	},

	{
		Name: "DeleteDashboard",
		Args: Args{Method: "Delete", URL: "/dashboards/simple"},
		Want: Want{
			Status: 204,
			Body:   nil,
		},
	},

	{
		Name: "ListJobs",
		Args: Args{Method: "Get", URL: "/jobs"},
		Want: Want{
			Status: 200,
			Body:   []any{map[string]any{"automation": "hash.sha1", "id": "b81c2366-ea37-43d2-b61b-03afdc21d985", "payload": "test", "status": "created"}},
		},
	},

	{
		Name: "RunJob",
		Args: Args{Method: "Post", URL: "/jobs", Data: map[string]any{"automation": "hash.sha1", "payload": "test"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"automation": "hash.sha1", "id": "87390749-2125-4a87-91c5-da7e3f9bebf1", "payload": "test", "status": "created"},
		},
	},

	{
		Name: "GetJob",
		Args: Args{Method: "Get", URL: "/jobs/b81c2366-ea37-43d2-b61b-03afdc21d985"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"automation": "hash.sha1", "id": "b81c2366-ea37-43d2-b61b-03afdc21d985", "payload": "test", "status": "created"},
		},
	},

	{
		Name: "UpdateJob",
		Args: Args{Method: "Put", URL: "/jobs/b81c2366-ea37-43d2-b61b-03afdc21d985", Data: map[string]any{"running": false, "status": "failed"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"automation": "hash.sha1", "id": "b81c2366-ea37-43d2-b61b-03afdc21d985", "payload": "test", "status": "failed"},
		},
	},

	{
		Name: "GetLogs",
		Args: Args{Method: "Get", URL: "/logs/tickets%252F294511"},
		Want: Want{
			Status: 200,
			Body:   []any{map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "creator": "bob", "message": "Fail run account resist lend solve incident centre priority temperature. Cause change distribution examine location technique shape partner milk customer. Rail tea plate soil report cook railway interpretation breath action. Exercise dream accept park conclusion addition shoot assistance may answer. Gold writer link stop combine hear power name commitment operation. Determine lifespan support grow degree henry exclude detail set religion. Direct library policy convention chain retain discover ride walk student. Gather proposal select march aspect play noise avoid encourage employ. Assessment preserve transport combine wish influence income guess run stand. Charge limit crime ignore statement foundation study issue stop claim.", "reference": "tickets/294511", "type": "manual"}},
		},
	},

	{
		Name: "ListPlaybooks",
		Args: Args{Method: "Get", URL: "/playbooks"},
		Want: Want{
			Status: 200,
			Body:   []any{map[string]any{"id": "phishing", "name": "Phishing", "yaml": "name: Phishing\ntasks:\n  board:\n    name: Board Involvement?\n    description: Is a board member involved?\n    type: input\n    schema:\n      properties:\n        boardInvolved:\n          default: false\n          title: A board member is involved.\n          type: boolean\n      required:\n        - boardInvolved\n      title: Board Involvement?\n      type: object\n    next:\n      escalate: \"boardInvolved == true\"\n      mail-available: \"boardInvolved == false\"\n\n  escalate:\n    name: Escalate to CISO\n    description: Please escalate the task to the CISO\n    type: task\n\n  mail-available:\n    name: Mail available\n    type: input\n    schema:\n      oneOf:\n        - properties:\n            mail:\n              title: Mail\n              type: string\n              x-display: textarea\n            schemaKey:\n              const: 'yes'\n              type: string\n          required:\n            - mail\n          title: 'Yes'\n        - properties:\n            schemaKey:\n              const: 'no'\n              type: string\n          title: 'No'\n      title: Mail available\n      type: object\n    next:\n      block-sender: \"schemaKey == 'yes'\"\n      extract-iocs: \"schemaKey == 'yes'\"\n      search-email-gateway: \"schemaKey == 'no'\"\n\n  search-email-gateway:\n    name: Search email gateway\n    description: Please search email-gateway for the phishing mail.\n    type: task\n    next:\n      extract-iocs:\n\n  block-sender:\n    name: Block sender\n    type: task\n    next:\n      extract-iocs:\n\n  extract-iocs:\n    name: Extract IOCs\n    description: Please insert the IOCs\n    type: input\n    schema:\n      properties:\n        iocs:\n          items:\n            type: string\n          title: IOCs\n          type: array\n      title: Extract IOCs\n      type: object\n    next:\n      block-iocs:\n\n  block-iocs:\n    name: Block IOCs\n    type: task\n"}, map[string]any{"id": "simple", "name": "Simple", "yaml": "name: Simple\ntasks:\n  input:\n    name: Enter something to hash\n    type: input\n    schema:\n      title: Something\n      type: object\n      properties:\n        something:\n          type: string\n          title: Something\n          default: \"\"\n    next:\n      hash: \"something != ''\"\n\n  hash:\n    name: Hash the something\n    type: automation\n    automation: hash.sha1\n    payload:\n      default: \"playbook.tasks['input'].data['something']\"\n    next:\n      comment: \"hash != ''\"\n\n  comment:\n    name: Comment the hash\n    type: automation\n    automation: comment\n    payload:\n      default: \"playbook.tasks['hash'].data['hash']\"\n    next:\n      done: \"done\"\n\n  done:\n    name: You can close this case now\n    type: task\n"}},
		},
	},

	{
		Name: "CreatePlaybook",
		Args: Args{Method: "Post", URL: "/playbooks", Data: map[string]any{"yaml": "name: Simple2\ntasks:\n  input:\n    name: Upload malware if possible\n    type: input\n    schema:\n      title: Malware\n      type: object\n      properties:\n        malware:\n          type: string\n          title: Select malware\n          default: \"\"\n    next:\n      hash: \"malware != ''\"\n\n  hash:\n    name: Hash the malware\n    type: automation\n    automation: hash.sha1\n    payload:\n      default: \"playbook.tasks['input'].data['malware']\"\n    next:\n      escalate:\n\n  escalate:\n    name: Escalate to malware team\n    type: task\n"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"id": "simple-2", "name": "Simple2", "yaml": "name: Simple2\ntasks:\n  input:\n    name: Upload malware if possible\n    type: input\n    schema:\n      title: Malware\n      type: object\n      properties:\n        malware:\n          type: string\n          title: Select malware\n          default: \"\"\n    next:\n      hash: \"malware != ''\"\n\n  hash:\n    name: Hash the malware\n    type: automation\n    automation: hash.sha1\n    payload:\n      default: \"playbook.tasks['input'].data['malware']\"\n    next:\n      escalate:\n\n  escalate:\n    name: Escalate to malware team\n    type: task\n"},
		},
	},

	{
		Name: "GetPlaybook",
		Args: Args{Method: "Get", URL: "/playbooks/simple"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"id": "simple", "name": "Simple", "yaml": "name: Simple\ntasks:\n  input:\n    name: Enter something to hash\n    type: input\n    schema:\n      title: Something\n      type: object\n      properties:\n        something:\n          type: string\n          title: Something\n          default: \"\"\n    next:\n      hash: \"something != ''\"\n\n  hash:\n    name: Hash the something\n    type: automation\n    automation: hash.sha1\n    payload:\n      default: \"playbook.tasks['input'].data['something']\"\n    next:\n      comment: \"hash != ''\"\n\n  comment:\n    name: Comment the hash\n    type: automation\n    automation: comment\n    payload:\n      default: \"playbook.tasks['hash'].data['hash']\"\n    next:\n      done: \"done\"\n\n  done:\n    name: You can close this case now\n    type: task\n"},
		},
	},

	{
		Name: "UpdatePlaybook",
		Args: Args{Method: "Put", URL: "/playbooks/simple", Data: map[string]any{"yaml": "name: Simple\ntasks:\n  input:\n    name: Upload malware if possible\n    type: input\n    schema:\n      title: Malware\n      type: object\n      properties:\n        malware:\n          type: string\n          title: Select malware\n          default: \"\"\n    next:\n      hash: \"malware != ''\"\n\n  hash:\n    name: Hash the malware\n    type: automation\n    automation: hash.sha1\n    payload:\n      default: \"playbook.tasks['input'].data['malware']\"\n    next:\n      escalate:\n\n  escalate:\n    name: Escalate to malware team\n    type: task\n"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"id": "simple", "name": "Simple", "yaml": "name: Simple\ntasks:\n  input:\n    name: Upload malware if possible\n    type: input\n    schema:\n      title: Malware\n      type: object\n      properties:\n        malware:\n          type: string\n          title: Select malware\n          default: \"\"\n    next:\n      hash: \"malware != ''\"\n\n  hash:\n    name: Hash the malware\n    type: automation\n    automation: hash.sha1\n    payload:\n      default: \"playbook.tasks['input'].data['malware']\"\n    next:\n      escalate:\n\n  escalate:\n    name: Escalate to malware team\n    type: task\n"},
		},
	},

	{
		Name: "DeletePlaybook",
		Args: Args{Method: "Delete", URL: "/playbooks/simple"},
		Want: Want{
			Status: 204,
			Body:   nil,
		},
	},

	{
		Name: "GetSettings",
		Args: Args{Method: "Get", URL: "/settings"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"artifactKinds": []any{map[string]any{"icon": "mdi-server", "id": "asset", "name": "Asset"}, map[string]any{"icon": "mdi-bullseye", "id": "ioc", "name": "IOC"}}, "artifactStates": []any{map[string]any{"color": "info", "icon": "mdi-help-circle-outline", "id": "unknown", "name": "Unknown"}, map[string]any{"color": "error", "icon": "mdi-skull", "id": "malicious", "name": "Malicious"}, map[string]any{"color": "success", "icon": "mdi-check", "id": "clean", "name": "Clean"}}, "ticketTypes": []any{map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-alert", "id": "alert", "name": "Alerts"}, map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-radioactive", "id": "incident", "name": "Incidents"}, map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-fingerprint", "id": "investigation", "name": "Forensic Investigations"}, map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-target", "id": "hunt", "name": "Threat Hunting"}}, "tier": "community", "timeformat": "yyyy-MM-dd hh:mm:ss", "version": "0.0.0-test"},
		},
	},

	{
		Name: "SaveSettings",
		Args: Args{Method: "Post", URL: "/settings", Data: map[string]any{"artifactKinds": []any{map[string]any{"icon": "mdi-server", "id": "asset", "name": "Asset"}, map[string]any{"icon": "mdi-bullseye", "id": "ioc", "name": "IOC"}}, "artifactStates": []any{map[string]any{"color": "info", "icon": "mdi-help-circle-outline", "id": "unknown", "name": "Unknown"}, map[string]any{"color": "error", "icon": "mdi-skull", "id": "malicious", "name": "Malicious"}, map[string]any{"color": "success", "icon": "mdi-check", "id": "clean", "name": "Clean"}}, "timeformat": "yyyy-MM-dd hh:mm:ss"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"artifactKinds": []any{map[string]any{"icon": "mdi-server", "id": "asset", "name": "Asset"}, map[string]any{"icon": "mdi-bullseye", "id": "ioc", "name": "IOC"}}, "artifactStates": []any{map[string]any{"color": "info", "icon": "mdi-help-circle-outline", "id": "unknown", "name": "Unknown"}, map[string]any{"color": "error", "icon": "mdi-skull", "id": "malicious", "name": "Malicious"}, map[string]any{"color": "success", "icon": "mdi-check", "id": "clean", "name": "Clean"}}, "ticketTypes": []any{map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-alert", "id": "alert", "name": "Alerts"}, map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-radioactive", "id": "incident", "name": "Incidents"}, map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-fingerprint", "id": "investigation", "name": "Forensic Investigations"}, map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-target", "id": "hunt", "name": "Threat Hunting"}}, "tier": "community", "timeformat": "yyyy-MM-dd hh:mm:ss", "version": "0.0.0-test"},
		},
	},

	{
		Name: "GetStatistics",
		Args: Args{Method: "Get", URL: "/statistics"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"open_tickets_per_user": map[string]any{}, "tickets_per_type": map[string]any{"alert": 2, "incident": 1}, "tickets_per_week": map[string]any{"2021-39": 3}, "unassigned": 0},
		},
	},

	{
		Name: "ListTasks",
		Args: Args{Method: "Get", URL: "/tasks"},
		Want: Want{
			Status: 200,
			Body:   nil,
		},
	},

	{
		Name: "ListTemplates",
		Args: Args{Method: "Get", URL: "/templates"},
		Want: Want{
			Status: 200,
			Body:   []any{map[string]any{"id": "default", "name": "Default", "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Default\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n"}},
		},
	},

	{
		Name: "CreateTemplate",
		Args: Args{Method: "Post", URL: "/templates", Data: map[string]any{"name": "My Template", "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"id": "my-template", "name": "My Template", "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n"},
		},
	},

	{
		Name: "GetTemplate",
		Args: Args{Method: "Get", URL: "/templates/default"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"id": "default", "name": "Default", "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Default\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n"},
		},
	},

	{
		Name: "UpdateTemplate",
		Args: Args{Method: "Put", URL: "/templates/default", Data: map[string]any{"name": "My Template", "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"id": "default", "name": "My Template", "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n"},
		},
	},

	{
		Name: "DeleteTemplate",
		Args: Args{Method: "Delete", URL: "/templates/default"},
		Want: Want{
			Status: 204,
			Body:   nil,
		},
	},

	{
		Name: "ListTickets",
		Args: Args{Method: "Get", URL: "/tickets"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"count": 3, "tickets": []any{map[string]any{"artifacts": []any{map[string]any{"name": "94d5cab6f5fe3422a447ab15436e7a672bc0c09a", "status": "unknown"}, map[string]any{"name": "http://www.customerviral.io/scalable/vertical/killer", "status": "clean"}, map[string]any{"name": "leadreintermediate.io", "status": "malicious"}}, "created": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "id": 8123, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "name": "live zebra", "owner": "demo", "playbooks": map[string]any{"phishing": map[string]any{"name": "Phishing", "tasks": map[string]any{"block-iocs": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block IOCs", "type": "task"}, "block-sender": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block sender", "next": map[string]any{"extract-iocs": ""}, "type": "task"}, "board": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Board Involvement?", "next": map[string]any{"escalate": "boardInvolved == true", "mail-available": "boardInvolved == false"}, "schema": map[string]any{"properties": map[string]any{"boardInvolved": map[string]any{"default": false, "title": "A board member is involved.", "type": "boolean"}}, "required": []any{"boardInvolved"}, "title": "Board Involvement?", "type": "object"}, "type": "input"}, "escalate": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Escalate to CISO", "type": "task"}, "extract-iocs": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Extract IOCs", "next": map[string]any{"block-iocs": ""}, "schema": map[string]any{"properties": map[string]any{"iocs": map[string]any{"items": map[string]any{"type": "string"}, "title": "IOCs", "type": "array"}}, "title": "Extract IOCs", "type": "object"}, "type": "input"}, "mail-available": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Mail available", "next": map[string]any{"block-sender": "schemaKey == 'yes'", "extract-iocs": "schemaKey == 'yes'", "search-email-gateway": "schemaKey == 'no'"}, "schema": map[string]any{"oneOf": []any{map[string]any{"properties": map[string]any{"mail": map[string]any{"title": "Mail", "type": "string", "x-display": "textarea"}, "schemaKey": map[string]any{"const": "yes", "type": "string"}}, "required": []any{"mail"}, "title": "Yes"}, map[string]any{"properties": map[string]any{"schemaKey": map[string]any{"const": "no", "type": "string"}}, "title": "No"}}, "title": "Mail available", "type": "object"}, "type": "input"}, "search-email-gateway": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Search email gateway", "next": map[string]any{"extract-iocs": ""}, "type": "task"}}}}, "references": []any{map[string]any{"href": "https://www.leadmaximize.net/e-services/back-end", "name": "performance"}, map[string]any{"href": "http://www.corporateinteractive.name/rich", "name": "autumn"}, map[string]any{"href": "https://www.corporateintuitive.org/intuitive/platforms/integrate", "name": "suggest"}}, "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n", "status": "closed", "type": "incident"}, map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8125, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "name": "phishing from selenafadel@von.com detected", "owner": "demo", "references": []any{map[string]any{"href": "https://www.seniorleading-edge.name/users/efficient", "name": "recovery"}, map[string]any{"href": "http://www.dynamicseamless.com/clicks-and-mortar", "name": "force"}, map[string]any{"href": "http://www.leadscalable.biz/envisioneer", "name": "fund"}}, "schema": "{}", "status": "closed", "type": "alert"}, map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8126, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "name": "Surfaceintroduce virus detected", "owner": "demo", "references": []any{map[string]any{"href": "http://www.centralworld-class.io/synthesize", "name": "university"}, map[string]any{"href": "https://www.futurevirtual.org/supply-chains/markets/sticky/iterate", "name": "goal"}, map[string]any{"href": "http://www.chiefsyndicate.io/action-items", "name": "unemployment"}}, "schema": "{}", "status": "closed", "type": "alert"}}},
		},
	},

	{
		Name: "CreateTicket",
		Args: Args{Method: "Post", URL: "/tickets", Data: map[string]any{"id": 123, "name": "Wannacry infection", "owner": "bob", "status": "open", "type": "incident"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "id": 123, "modified": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "name": "Wannacry infection", "owner": "bob", "schema": "{}", "status": "open", "type": "incident"},
		},
	},

	{
		Name: "CreateTicketBatch",
		Args: Args{Method: "Post", URL: "/tickets/batch", Data: []any{map[string]any{"id": 123, "name": "Wannacry infection", "owner": "bob", "status": "open", "type": "incident"}}},
		Want: Want{
			Status: 204,
			Body:   nil,
		},
	},

	{
		Name: "GetTicket",
		Args: Args{Method: "Get", URL: "/tickets/8125"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8125, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "name": "phishing from selenafadel@von.com detected", "owner": "demo", "references": []any{map[string]any{"href": "https://www.seniorleading-edge.name/users/efficient", "name": "recovery"}, map[string]any{"href": "http://www.dynamicseamless.com/clicks-and-mortar", "name": "force"}, map[string]any{"href": "http://www.leadscalable.biz/envisioneer", "name": "fund"}}, "schema": "{}", "status": "closed", "tickets": []any{map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8126, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "name": "Surfaceintroduce virus detected", "owner": "demo", "references": []any{map[string]any{"href": "http://www.centralworld-class.io/synthesize", "name": "university"}, map[string]any{"href": "https://www.futurevirtual.org/supply-chains/markets/sticky/iterate", "name": "goal"}, map[string]any{"href": "http://www.chiefsyndicate.io/action-items", "name": "unemployment"}}, "schema": "{}", "status": "closed", "type": "alert"}}, "type": "alert"},
		},
	},

	{
		Name: "UpdateTicket",
		Args: Args{Method: "Put", URL: "/tickets/8125", Data: map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "modified": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "name": "phishing from selenafadel@von.org detected", "owner": "demo", "references": []any{map[string]any{"href": "https://www.seniorleading-edge.name/users/efficient", "name": "recovery"}, map[string]any{"href": "http://www.dynamicseamless.com/clicks-and-mortar", "name": "force"}, map[string]any{"href": "http://www.leadscalable.biz/envisioneer", "name": "fund"}}, "schema": "{}", "status": "closed", "type": "alert"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "id": 8125, "modified": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "name": "phishing from selenafadel@von.org detected", "owner": "demo", "references": []any{map[string]any{"href": "https://www.seniorleading-edge.name/users/efficient", "name": "recovery"}, map[string]any{"href": "http://www.dynamicseamless.com/clicks-and-mortar", "name": "force"}, map[string]any{"href": "http://www.leadscalable.biz/envisioneer", "name": "fund"}}, "schema": "{}", "status": "closed", "tickets": []any{map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8126, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "name": "Surfaceintroduce virus detected", "owner": "demo", "references": []any{map[string]any{"href": "http://www.centralworld-class.io/synthesize", "name": "university"}, map[string]any{"href": "https://www.futurevirtual.org/supply-chains/markets/sticky/iterate", "name": "goal"}, map[string]any{"href": "http://www.chiefsyndicate.io/action-items", "name": "unemployment"}}, "schema": "{}", "status": "closed", "type": "alert"}}, "type": "alert"},
		},
	},

	{
		Name: "DeleteTicket",
		Args: Args{Method: "Delete", URL: "/tickets/8125"},
		Want: Want{
			Status: 204,
			Body:   nil,
		},
	},

	{
		Name: "AddArtifact",
		Args: Args{Method: "Post", URL: "/tickets/8123/artifacts", Data: map[string]any{"name": "2.2.2.2"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"artifacts": []any{map[string]any{"name": "94d5cab6f5fe3422a447ab15436e7a672bc0c09a", "status": "unknown"}, map[string]any{"name": "http://www.customerviral.io/scalable/vertical/killer", "status": "clean"}, map[string]any{"name": "leadreintermediate.io", "status": "malicious"}, map[string]any{"name": "2.2.2.2", "status": "unknown", "type": "ip"}}, "created": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "id": 8123, "modified": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "name": "live zebra", "owner": "demo", "playbooks": map[string]any{"phishing": map[string]any{"name": "Phishing", "tasks": map[string]any{"block-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block IOCs", "order": 6, "type": "task"}, "block-sender": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block sender", "next": map[string]any{"extract-iocs": ""}, "order": 3, "type": "task"}, "board": map[string]any{"active": true, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Board Involvement?", "next": map[string]any{"escalate": "boardInvolved == true", "mail-available": "boardInvolved == false"}, "order": 0, "schema": map[string]any{"properties": map[string]any{"boardInvolved": map[string]any{"default": false, "title": "A board member is involved.", "type": "boolean"}}, "required": []any{"boardInvolved"}, "title": "Board Involvement?", "type": "object"}, "type": "input"}, "escalate": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Escalate to CISO", "order": 1, "type": "task"}, "extract-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Extract IOCs", "next": map[string]any{"block-iocs": ""}, "order": 5, "schema": map[string]any{"properties": map[string]any{"iocs": map[string]any{"items": map[string]any{"type": "string"}, "title": "IOCs", "type": "array"}}, "title": "Extract IOCs", "type": "object"}, "type": "input"}, "mail-available": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Mail available", "next": map[string]any{"block-sender": "schemaKey == 'yes'", "extract-iocs": "schemaKey == 'yes'", "search-email-gateway": "schemaKey == 'no'"}, "order": 2, "schema": map[string]any{"oneOf": []any{map[string]any{"properties": map[string]any{"mail": map[string]any{"title": "Mail", "type": "string", "x-display": "textarea"}, "schemaKey": map[string]any{"const": "yes", "type": "string"}}, "required": []any{"mail"}, "title": "Yes"}, map[string]any{"properties": map[string]any{"schemaKey": map[string]any{"const": "no", "type": "string"}}, "title": "No"}}, "title": "Mail available", "type": "object"}, "type": "input"}, "search-email-gateway": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Search email gateway", "next": map[string]any{"extract-iocs": ""}, "order": 4, "type": "task"}}}}, "references": []any{map[string]any{"href": "https://www.leadmaximize.net/e-services/back-end", "name": "performance"}, map[string]any{"href": "http://www.corporateinteractive.name/rich", "name": "autumn"}, map[string]any{"href": "https://www.corporateintuitive.org/intuitive/platforms/integrate", "name": "suggest"}}, "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n", "status": "closed", "type": "incident"},
		},
	},

	{
		Name: "GetArtifact",
		Args: Args{Method: "Get", URL: "/tickets/8123/artifacts/leadreintermediate.io"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"name": "leadreintermediate.io", "status": "malicious"},
		},
	},

	{
		Name: "SetArtifact",
		Args: Args{Method: "Put", URL: "/tickets/8123/artifacts/leadreintermediate.io", Data: map[string]any{"name": "leadreintermediate.io", "status": "clean"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"artifacts": []any{map[string]any{"name": "94d5cab6f5fe3422a447ab15436e7a672bc0c09a", "status": "unknown"}, map[string]any{"name": "http://www.customerviral.io/scalable/vertical/killer", "status": "clean"}, map[string]any{"name": "leadreintermediate.io", "status": "clean"}}, "created": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "id": 8123, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "name": "live zebra", "owner": "demo", "playbooks": map[string]any{"phishing": map[string]any{"name": "Phishing", "tasks": map[string]any{"block-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block IOCs", "order": 6, "type": "task"}, "block-sender": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block sender", "next": map[string]any{"extract-iocs": ""}, "order": 3, "type": "task"}, "board": map[string]any{"active": true, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Board Involvement?", "next": map[string]any{"escalate": "boardInvolved == true", "mail-available": "boardInvolved == false"}, "order": 0, "schema": map[string]any{"properties": map[string]any{"boardInvolved": map[string]any{"default": false, "title": "A board member is involved.", "type": "boolean"}}, "required": []any{"boardInvolved"}, "title": "Board Involvement?", "type": "object"}, "type": "input"}, "escalate": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Escalate to CISO", "order": 1, "type": "task"}, "extract-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Extract IOCs", "next": map[string]any{"block-iocs": ""}, "order": 5, "schema": map[string]any{"properties": map[string]any{"iocs": map[string]any{"items": map[string]any{"type": "string"}, "title": "IOCs", "type": "array"}}, "title": "Extract IOCs", "type": "object"}, "type": "input"}, "mail-available": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Mail available", "next": map[string]any{"block-sender": "schemaKey == 'yes'", "extract-iocs": "schemaKey == 'yes'", "search-email-gateway": "schemaKey == 'no'"}, "order": 2, "schema": map[string]any{"oneOf": []any{map[string]any{"properties": map[string]any{"mail": map[string]any{"title": "Mail", "type": "string", "x-display": "textarea"}, "schemaKey": map[string]any{"const": "yes", "type": "string"}}, "required": []any{"mail"}, "title": "Yes"}, map[string]any{"properties": map[string]any{"schemaKey": map[string]any{"const": "no", "type": "string"}}, "title": "No"}}, "title": "Mail available", "type": "object"}, "type": "input"}, "search-email-gateway": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Search email gateway", "next": map[string]any{"extract-iocs": ""}, "order": 4, "type": "task"}}}}, "references": []any{map[string]any{"href": "https://www.leadmaximize.net/e-services/back-end", "name": "performance"}, map[string]any{"href": "http://www.corporateinteractive.name/rich", "name": "autumn"}, map[string]any{"href": "https://www.corporateintuitive.org/intuitive/platforms/integrate", "name": "suggest"}}, "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n", "status": "closed", "type": "incident"},
		},
	},

	{
		Name: "RemoveArtifact",
		Args: Args{Method: "Delete", URL: "/tickets/8123/artifacts/leadreintermediate.io"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"artifacts": []any{map[string]any{"name": "94d5cab6f5fe3422a447ab15436e7a672bc0c09a", "status": "unknown"}, map[string]any{"name": "http://www.customerviral.io/scalable/vertical/killer", "status": "clean"}}, "created": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "id": 8123, "modified": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "name": "live zebra", "owner": "demo", "playbooks": map[string]any{"phishing": map[string]any{"name": "Phishing", "tasks": map[string]any{"block-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block IOCs", "order": 6, "type": "task"}, "block-sender": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block sender", "next": map[string]any{"extract-iocs": ""}, "order": 3, "type": "task"}, "board": map[string]any{"active": true, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Board Involvement?", "next": map[string]any{"escalate": "boardInvolved == true", "mail-available": "boardInvolved == false"}, "order": 0, "schema": map[string]any{"properties": map[string]any{"boardInvolved": map[string]any{"default": false, "title": "A board member is involved.", "type": "boolean"}}, "required": []any{"boardInvolved"}, "title": "Board Involvement?", "type": "object"}, "type": "input"}, "escalate": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Escalate to CISO", "order": 1, "type": "task"}, "extract-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Extract IOCs", "next": map[string]any{"block-iocs": ""}, "order": 5, "schema": map[string]any{"properties": map[string]any{"iocs": map[string]any{"items": map[string]any{"type": "string"}, "title": "IOCs", "type": "array"}}, "title": "Extract IOCs", "type": "object"}, "type": "input"}, "mail-available": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Mail available", "next": map[string]any{"block-sender": "schemaKey == 'yes'", "extract-iocs": "schemaKey == 'yes'", "search-email-gateway": "schemaKey == 'no'"}, "order": 2, "schema": map[string]any{"oneOf": []any{map[string]any{"properties": map[string]any{"mail": map[string]any{"title": "Mail", "type": "string", "x-display": "textarea"}, "schemaKey": map[string]any{"const": "yes", "type": "string"}}, "required": []any{"mail"}, "title": "Yes"}, map[string]any{"properties": map[string]any{"schemaKey": map[string]any{"const": "no", "type": "string"}}, "title": "No"}}, "title": "Mail available", "type": "object"}, "type": "input"}, "search-email-gateway": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Search email gateway", "next": map[string]any{"extract-iocs": ""}, "order": 4, "type": "task"}}}}, "references": []any{map[string]any{"href": "https://www.leadmaximize.net/e-services/back-end", "name": "performance"}, map[string]any{"href": "http://www.corporateinteractive.name/rich", "name": "autumn"}, map[string]any{"href": "https://www.corporateintuitive.org/intuitive/platforms/integrate", "name": "suggest"}}, "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n", "status": "closed", "type": "incident"},
		},
	},

	{
		Name: "EnrichArtifact",
		Args: Args{Method: "Post", URL: "/tickets/8123/artifacts/leadreintermediate.io/enrich", Data: map[string]any{"data": map[string]any{"hash": "b7a067a742c20d07a7456646de89bc2d408a1153"}, "name": "hash.sha1"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"artifacts": []any{map[string]any{"name": "94d5cab6f5fe3422a447ab15436e7a672bc0c09a", "status": "unknown"}, map[string]any{"name": "http://www.customerviral.io/scalable/vertical/killer", "status": "clean"}, map[string]any{"enrichments": map[string]any{"hash.sha1": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "data": map[string]any{"hash": "b7a067a742c20d07a7456646de89bc2d408a1153"}, "name": "hash.sha1"}}, "name": "leadreintermediate.io", "status": "malicious"}}, "created": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "id": 8123, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "name": "live zebra", "owner": "demo", "playbooks": map[string]any{"phishing": map[string]any{"name": "Phishing", "tasks": map[string]any{"block-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block IOCs", "order": 6, "type": "task"}, "block-sender": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block sender", "next": map[string]any{"extract-iocs": ""}, "order": 3, "type": "task"}, "board": map[string]any{"active": true, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Board Involvement?", "next": map[string]any{"escalate": "boardInvolved == true", "mail-available": "boardInvolved == false"}, "order": 0, "schema": map[string]any{"properties": map[string]any{"boardInvolved": map[string]any{"default": false, "title": "A board member is involved.", "type": "boolean"}}, "required": []any{"boardInvolved"}, "title": "Board Involvement?", "type": "object"}, "type": "input"}, "escalate": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Escalate to CISO", "order": 1, "type": "task"}, "extract-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Extract IOCs", "next": map[string]any{"block-iocs": ""}, "order": 5, "schema": map[string]any{"properties": map[string]any{"iocs": map[string]any{"items": map[string]any{"type": "string"}, "title": "IOCs", "type": "array"}}, "title": "Extract IOCs", "type": "object"}, "type": "input"}, "mail-available": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Mail available", "next": map[string]any{"block-sender": "schemaKey == 'yes'", "extract-iocs": "schemaKey == 'yes'", "search-email-gateway": "schemaKey == 'no'"}, "order": 2, "schema": map[string]any{"oneOf": []any{map[string]any{"properties": map[string]any{"mail": map[string]any{"title": "Mail", "type": "string", "x-display": "textarea"}, "schemaKey": map[string]any{"const": "yes", "type": "string"}}, "required": []any{"mail"}, "title": "Yes"}, map[string]any{"properties": map[string]any{"schemaKey": map[string]any{"const": "no", "type": "string"}}, "title": "No"}}, "title": "Mail available", "type": "object"}, "type": "input"}, "search-email-gateway": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Search email gateway", "next": map[string]any{"extract-iocs": ""}, "order": 4, "type": "task"}}}}, "references": []any{map[string]any{"href": "https://www.leadmaximize.net/e-services/back-end", "name": "performance"}, map[string]any{"href": "http://www.corporateinteractive.name/rich", "name": "autumn"}, map[string]any{"href": "https://www.corporateintuitive.org/intuitive/platforms/integrate", "name": "suggest"}}, "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n", "status": "closed", "type": "incident"},
		},
	},

	{
		Name: "RunArtifact",
		Args: Args{Method: "Post", URL: "/tickets/8123/artifacts/leadreintermediate.io/run/hash.sha1"},
		Want: Want{
			Status: 204,
			Body:   nil,
		},
	},

	{
		Name: "AddComment",
		Args: Args{Method: "Post", URL: "/tickets/8125/comments", Data: map[string]any{"message": "My first comment"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"comments": []any{map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "creator": "bob", "message": "My first comment"}}, "created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8125, "modified": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "name": "phishing from selenafadel@von.com detected", "owner": "demo", "references": []any{map[string]any{"href": "https://www.seniorleading-edge.name/users/efficient", "name": "recovery"}, map[string]any{"href": "http://www.dynamicseamless.com/clicks-and-mortar", "name": "force"}, map[string]any{"href": "http://www.leadscalable.biz/envisioneer", "name": "fund"}}, "schema": "{}", "status": "closed", "tickets": []any{map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8126, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "name": "Surfaceintroduce virus detected", "owner": "demo", "references": []any{map[string]any{"href": "http://www.centralworld-class.io/synthesize", "name": "university"}, map[string]any{"href": "https://www.futurevirtual.org/supply-chains/markets/sticky/iterate", "name": "goal"}, map[string]any{"href": "http://www.chiefsyndicate.io/action-items", "name": "unemployment"}}, "schema": "{}", "status": "closed", "type": "alert"}}, "type": "alert"},
		},
	},

	{
		Name: "RemoveComment",
		Args: Args{Method: "Delete", URL: "/tickets/8123/comments/0"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"artifacts": []any{map[string]any{"name": "94d5cab6f5fe3422a447ab15436e7a672bc0c09a", "status": "unknown"}, map[string]any{"name": "http://www.customerviral.io/scalable/vertical/killer", "status": "clean"}, map[string]any{"name": "leadreintermediate.io", "status": "malicious"}}, "created": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "id": 8123, "modified": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "name": "live zebra", "owner": "demo", "playbooks": map[string]any{"phishing": map[string]any{"name": "Phishing", "tasks": map[string]any{"block-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block IOCs", "order": 6, "type": "task"}, "block-sender": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block sender", "next": map[string]any{"extract-iocs": ""}, "order": 3, "type": "task"}, "board": map[string]any{"active": true, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Board Involvement?", "next": map[string]any{"escalate": "boardInvolved == true", "mail-available": "boardInvolved == false"}, "order": 0, "schema": map[string]any{"properties": map[string]any{"boardInvolved": map[string]any{"default": false, "title": "A board member is involved.", "type": "boolean"}}, "required": []any{"boardInvolved"}, "title": "Board Involvement?", "type": "object"}, "type": "input"}, "escalate": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Escalate to CISO", "order": 1, "type": "task"}, "extract-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Extract IOCs", "next": map[string]any{"block-iocs": ""}, "order": 5, "schema": map[string]any{"properties": map[string]any{"iocs": map[string]any{"items": map[string]any{"type": "string"}, "title": "IOCs", "type": "array"}}, "title": "Extract IOCs", "type": "object"}, "type": "input"}, "mail-available": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Mail available", "next": map[string]any{"block-sender": "schemaKey == 'yes'", "extract-iocs": "schemaKey == 'yes'", "search-email-gateway": "schemaKey == 'no'"}, "order": 2, "schema": map[string]any{"oneOf": []any{map[string]any{"properties": map[string]any{"mail": map[string]any{"title": "Mail", "type": "string", "x-display": "textarea"}, "schemaKey": map[string]any{"const": "yes", "type": "string"}}, "required": []any{"mail"}, "title": "Yes"}, map[string]any{"properties": map[string]any{"schemaKey": map[string]any{"const": "no", "type": "string"}}, "title": "No"}}, "title": "Mail available", "type": "object"}, "type": "input"}, "search-email-gateway": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Search email gateway", "next": map[string]any{"extract-iocs": ""}, "order": 4, "type": "task"}}}}, "references": []any{map[string]any{"href": "https://www.leadmaximize.net/e-services/back-end", "name": "performance"}, map[string]any{"href": "http://www.corporateinteractive.name/rich", "name": "autumn"}, map[string]any{"href": "https://www.corporateintuitive.org/intuitive/platforms/integrate", "name": "suggest"}}, "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n", "status": "closed", "type": "incident"},
		},
	},

	{
		Name: "AddTicketPlaybook",
		Args: Args{Method: "Post", URL: "/tickets/8125/playbooks", Data: map[string]any{"yaml": "name: Simple\ntasks:\n  input:\n    name: Upload malware if possible\n    type: input\n    schema:\n      title: Malware\n      type: object\n      properties:\n        malware:\n          type: string\n          title: Select malware\n          default: \"\"\n    next:\n      hash: \"malware != ''\"\n\n  hash:\n    name: Hash the malware\n    type: automation\n    automation: hash.sha1\n    payload:\n      default: \"playbook.tasks['input'].data['malware']\"\n    next:\n      escalate:\n\n  escalate:\n    name: Escalate to malware team\n    type: task\n"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8125, "modified": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "name": "phishing from selenafadel@von.com detected", "owner": "demo", "playbooks": map[string]any{"simple": map[string]any{"name": "Simple", "tasks": map[string]any{"escalate": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Escalate to malware team", "order": 2, "type": "task"}, "hash": map[string]any{"active": false, "automation": "hash.sha1", "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Hash the malware", "next": map[string]any{"escalate": ""}, "order": 1, "payload": map[string]any{"default": "playbook.tasks['input'].data['malware']"}, "type": "automation"}, "input": map[string]any{"active": true, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Upload malware if possible", "next": map[string]any{"hash": "malware != ''"}, "order": 0, "schema": map[string]any{"properties": map[string]any{"malware": map[string]any{"default": "", "title": "Select malware", "type": "string"}}, "title": "Malware", "type": "object"}, "type": "input"}}}}, "references": []any{map[string]any{"href": "https://www.seniorleading-edge.name/users/efficient", "name": "recovery"}, map[string]any{"href": "http://www.dynamicseamless.com/clicks-and-mortar", "name": "force"}, map[string]any{"href": "http://www.leadscalable.biz/envisioneer", "name": "fund"}}, "schema": "{}", "status": "closed", "tickets": []any{map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8126, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "name": "Surfaceintroduce virus detected", "owner": "demo", "references": []any{map[string]any{"href": "http://www.centralworld-class.io/synthesize", "name": "university"}, map[string]any{"href": "https://www.futurevirtual.org/supply-chains/markets/sticky/iterate", "name": "goal"}, map[string]any{"href": "http://www.chiefsyndicate.io/action-items", "name": "unemployment"}}, "schema": "{}", "status": "closed", "type": "alert"}}, "type": "alert"},
		},
	},

	{
		Name: "RemoveTicketPlaybook",
		Args: Args{Method: "Delete", URL: "/tickets/8123/playbooks/phishing"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"artifacts": []any{map[string]any{"name": "94d5cab6f5fe3422a447ab15436e7a672bc0c09a", "status": "unknown"}, map[string]any{"name": "http://www.customerviral.io/scalable/vertical/killer", "status": "clean"}, map[string]any{"name": "leadreintermediate.io", "status": "malicious"}}, "created": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "id": 8123, "modified": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "name": "live zebra", "owner": "demo", "references": []any{map[string]any{"href": "https://www.leadmaximize.net/e-services/back-end", "name": "performance"}, map[string]any{"href": "http://www.corporateinteractive.name/rich", "name": "autumn"}, map[string]any{"href": "https://www.corporateintuitive.org/intuitive/platforms/integrate", "name": "suggest"}}, "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n", "status": "closed", "type": "incident"},
		},
	},

	{
		Name: "SetTaskData",
		Args: Args{Method: "Put", URL: "/tickets/8123/playbooks/phishing/task/board", Data: map[string]any{"boardInvolved": true}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"artifacts": []any{map[string]any{"name": "94d5cab6f5fe3422a447ab15436e7a672bc0c09a", "status": "unknown"}, map[string]any{"name": "http://www.customerviral.io/scalable/vertical/killer", "status": "clean"}, map[string]any{"name": "leadreintermediate.io", "status": "malicious"}}, "created": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "id": 8123, "modified": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "name": "live zebra", "owner": "demo", "playbooks": map[string]any{"phishing": map[string]any{"name": "Phishing", "tasks": map[string]any{"block-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block IOCs", "order": 6, "type": "task"}, "block-sender": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block sender", "next": map[string]any{"extract-iocs": ""}, "order": 3, "type": "task"}, "board": map[string]any{"active": true, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "data": map[string]any{"boardInvolved": true}, "done": false, "name": "Board Involvement?", "next": map[string]any{"escalate": "boardInvolved == true", "mail-available": "boardInvolved == false"}, "order": 0, "schema": map[string]any{"properties": map[string]any{"boardInvolved": map[string]any{"default": false, "title": "A board member is involved.", "type": "boolean"}}, "required": []any{"boardInvolved"}, "title": "Board Involvement?", "type": "object"}, "type": "input"}, "escalate": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Escalate to CISO", "order": 1, "type": "task"}, "extract-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Extract IOCs", "next": map[string]any{"block-iocs": ""}, "order": 5, "schema": map[string]any{"properties": map[string]any{"iocs": map[string]any{"items": map[string]any{"type": "string"}, "title": "IOCs", "type": "array"}}, "title": "Extract IOCs", "type": "object"}, "type": "input"}, "mail-available": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Mail available", "next": map[string]any{"block-sender": "schemaKey == 'yes'", "extract-iocs": "schemaKey == 'yes'", "search-email-gateway": "schemaKey == 'no'"}, "order": 2, "schema": map[string]any{"oneOf": []any{map[string]any{"properties": map[string]any{"mail": map[string]any{"title": "Mail", "type": "string", "x-display": "textarea"}, "schemaKey": map[string]any{"const": "yes", "type": "string"}}, "required": []any{"mail"}, "title": "Yes"}, map[string]any{"properties": map[string]any{"schemaKey": map[string]any{"const": "no", "type": "string"}}, "title": "No"}}, "title": "Mail available", "type": "object"}, "type": "input"}, "search-email-gateway": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Search email gateway", "next": map[string]any{"extract-iocs": ""}, "order": 4, "type": "task"}}}}, "references": []any{map[string]any{"href": "https://www.leadmaximize.net/e-services/back-end", "name": "performance"}, map[string]any{"href": "http://www.corporateinteractive.name/rich", "name": "autumn"}, map[string]any{"href": "https://www.corporateintuitive.org/intuitive/platforms/integrate", "name": "suggest"}}, "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n", "status": "closed", "type": "incident"},
		},
	},

	{
		Name: "CompleteTask",
		Args: Args{Method: "Put", URL: "/tickets/8123/playbooks/phishing/task/board/complete", Data: map[string]any{"boardInvolved": true}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"artifacts": []any{map[string]any{"name": "94d5cab6f5fe3422a447ab15436e7a672bc0c09a", "status": "unknown"}, map[string]any{"name": "http://www.customerviral.io/scalable/vertical/killer", "status": "clean"}, map[string]any{"name": "leadreintermediate.io", "status": "malicious"}}, "created": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "id": 8123, "modified": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "name": "live zebra", "owner": "demo", "playbooks": map[string]any{"phishing": map[string]any{"name": "Phishing", "tasks": map[string]any{"block-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block IOCs", "order": 6, "type": "task"}, "block-sender": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block sender", "next": map[string]any{"extract-iocs": ""}, "order": 3, "type": "task"}, "board": map[string]any{"active": false, "closed": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "data": map[string]any{"boardInvolved": true}, "done": true, "name": "Board Involvement?", "next": map[string]any{"escalate": "boardInvolved == true", "mail-available": "boardInvolved == false"}, "order": 0, "schema": map[string]any{"properties": map[string]any{"boardInvolved": map[string]any{"default": false, "title": "A board member is involved.", "type": "boolean"}}, "required": []any{"boardInvolved"}, "title": "Board Involvement?", "type": "object"}, "type": "input"}, "escalate": map[string]any{"active": true, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Escalate to CISO", "order": 1, "type": "task"}, "extract-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Extract IOCs", "next": map[string]any{"block-iocs": ""}, "order": 5, "schema": map[string]any{"properties": map[string]any{"iocs": map[string]any{"items": map[string]any{"type": "string"}, "title": "IOCs", "type": "array"}}, "title": "Extract IOCs", "type": "object"}, "type": "input"}, "mail-available": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Mail available", "next": map[string]any{"block-sender": "schemaKey == 'yes'", "extract-iocs": "schemaKey == 'yes'", "search-email-gateway": "schemaKey == 'no'"}, "order": 2, "schema": map[string]any{"oneOf": []any{map[string]any{"properties": map[string]any{"mail": map[string]any{"title": "Mail", "type": "string", "x-display": "textarea"}, "schemaKey": map[string]any{"const": "yes", "type": "string"}}, "required": []any{"mail"}, "title": "Yes"}, map[string]any{"properties": map[string]any{"schemaKey": map[string]any{"const": "no", "type": "string"}}, "title": "No"}}, "title": "Mail available", "type": "object"}, "type": "input"}, "search-email-gateway": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Search email gateway", "next": map[string]any{"extract-iocs": ""}, "order": 4, "type": "task"}}}}, "references": []any{map[string]any{"href": "https://www.leadmaximize.net/e-services/back-end", "name": "performance"}, map[string]any{"href": "http://www.corporateinteractive.name/rich", "name": "autumn"}, map[string]any{"href": "https://www.corporateintuitive.org/intuitive/platforms/integrate", "name": "suggest"}}, "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n", "status": "closed", "type": "incident"},
		},
	},

	{
		Name: "SetTaskOwner",
		Args: Args{Method: "Put", URL: "/tickets/8123/playbooks/phishing/task/board/owner", Data: "eve"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"artifacts": []any{map[string]any{"name": "94d5cab6f5fe3422a447ab15436e7a672bc0c09a", "status": "unknown"}, map[string]any{"name": "http://www.customerviral.io/scalable/vertical/killer", "status": "clean"}, map[string]any{"name": "leadreintermediate.io", "status": "malicious"}}, "created": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "id": 8123, "modified": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "name": "live zebra", "owner": "demo", "playbooks": map[string]any{"phishing": map[string]any{"name": "Phishing", "tasks": map[string]any{"block-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block IOCs", "order": 6, "type": "task"}, "block-sender": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block sender", "next": map[string]any{"extract-iocs": ""}, "order": 3, "type": "task"}, "board": map[string]any{"active": true, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Board Involvement?", "next": map[string]any{"escalate": "boardInvolved == true", "mail-available": "boardInvolved == false"}, "order": 0, "owner": "eve", "schema": map[string]any{"properties": map[string]any{"boardInvolved": map[string]any{"default": false, "title": "A board member is involved.", "type": "boolean"}}, "required": []any{"boardInvolved"}, "title": "Board Involvement?", "type": "object"}, "type": "input"}, "escalate": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Escalate to CISO", "order": 1, "type": "task"}, "extract-iocs": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Extract IOCs", "next": map[string]any{"block-iocs": ""}, "order": 5, "schema": map[string]any{"properties": map[string]any{"iocs": map[string]any{"items": map[string]any{"type": "string"}, "title": "IOCs", "type": "array"}}, "title": "Extract IOCs", "type": "object"}, "type": "input"}, "mail-available": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Mail available", "next": map[string]any{"block-sender": "schemaKey == 'yes'", "extract-iocs": "schemaKey == 'yes'", "search-email-gateway": "schemaKey == 'no'"}, "order": 2, "schema": map[string]any{"oneOf": []any{map[string]any{"properties": map[string]any{"mail": map[string]any{"title": "Mail", "type": "string", "x-display": "textarea"}, "schemaKey": map[string]any{"const": "yes", "type": "string"}}, "required": []any{"mail"}, "title": "Yes"}, map[string]any{"properties": map[string]any{"schemaKey": map[string]any{"const": "no", "type": "string"}}, "title": "No"}}, "title": "Mail available", "type": "object"}, "type": "input"}, "search-email-gateway": map[string]any{"active": false, "created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Search email gateway", "next": map[string]any{"extract-iocs": ""}, "order": 4, "type": "task"}}}}, "references": []any{map[string]any{"href": "https://www.leadmaximize.net/e-services/back-end", "name": "performance"}, map[string]any{"href": "http://www.corporateinteractive.name/rich", "name": "autumn"}, map[string]any{"href": "https://www.corporateintuitive.org/intuitive/platforms/integrate", "name": "suggest"}}, "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n", "status": "closed", "type": "incident"},
		},
	},

	{
		Name: "RunTask",
		Args: Args{Method: "Post", URL: "/tickets/8123/playbooks/phishing/task/board/run"},
		Want: Want{
			Status: 204,
			Body:   nil,
		},
	},

	{
		Name: "SetReferences",
		Args: Args{Method: "Put", URL: "/tickets/8125/references", Data: []any{map[string]any{"href": "http://www.leadscalable.biz/envisioneer", "name": "fund"}}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8125, "modified": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "name": "phishing from selenafadel@von.com detected", "owner": "demo", "references": []any{map[string]any{"href": "http://www.leadscalable.biz/envisioneer", "name": "fund"}}, "schema": "{}", "status": "closed", "tickets": []any{map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8126, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "name": "Surfaceintroduce virus detected", "owner": "demo", "references": []any{map[string]any{"href": "http://www.centralworld-class.io/synthesize", "name": "university"}, map[string]any{"href": "https://www.futurevirtual.org/supply-chains/markets/sticky/iterate", "name": "goal"}, map[string]any{"href": "http://www.chiefsyndicate.io/action-items", "name": "unemployment"}}, "schema": "{}", "status": "closed", "type": "alert"}}, "type": "alert"},
		},
	},

	{
		Name: "SetSchema",
		Args: Args{Method: "Put", URL: "/tickets/8125/schema", Data: "{}"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8125, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "name": "phishing from selenafadel@von.com detected", "owner": "demo", "references": []any{map[string]any{"href": "https://www.seniorleading-edge.name/users/efficient", "name": "recovery"}, map[string]any{"href": "http://www.dynamicseamless.com/clicks-and-mortar", "name": "force"}, map[string]any{"href": "http://www.leadscalable.biz/envisioneer", "name": "fund"}}, "schema": "{}", "status": "closed", "tickets": []any{map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8126, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "name": "Surfaceintroduce virus detected", "owner": "demo", "references": []any{map[string]any{"href": "http://www.centralworld-class.io/synthesize", "name": "university"}, map[string]any{"href": "https://www.futurevirtual.org/supply-chains/markets/sticky/iterate", "name": "goal"}, map[string]any{"href": "http://www.chiefsyndicate.io/action-items", "name": "unemployment"}}, "schema": "{}", "status": "closed", "type": "alert"}}, "type": "alert"},
		},
	},

	{
		Name: "LinkTicket",
		Args: Args{Method: "Patch", URL: "/tickets/8126/tickets", Data: 8123},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8126, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "name": "Surfaceintroduce virus detected", "owner": "demo", "references": []any{map[string]any{"href": "http://www.centralworld-class.io/synthesize", "name": "university"}, map[string]any{"href": "https://www.futurevirtual.org/supply-chains/markets/sticky/iterate", "name": "goal"}, map[string]any{"href": "http://www.chiefsyndicate.io/action-items", "name": "unemployment"}}, "schema": "{}", "status": "closed", "tickets": []any{map[string]any{"artifacts": []any{map[string]any{"name": "94d5cab6f5fe3422a447ab15436e7a672bc0c09a", "status": "unknown"}, map[string]any{"name": "http://www.customerviral.io/scalable/vertical/killer", "status": "clean"}, map[string]any{"name": "leadreintermediate.io", "status": "malicious"}}, "created": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "id": 8123, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78206000, time.UTC), "name": "live zebra", "owner": "demo", "playbooks": map[string]any{"phishing": map[string]any{"name": "Phishing", "tasks": map[string]any{"block-iocs": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block IOCs", "type": "task"}, "block-sender": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Block sender", "next": map[string]any{"extract-iocs": ""}, "type": "task"}, "board": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Board Involvement?", "next": map[string]any{"escalate": "boardInvolved == true", "mail-available": "boardInvolved == false"}, "schema": map[string]any{"properties": map[string]any{"boardInvolved": map[string]any{"default": false, "title": "A board member is involved.", "type": "boolean"}}, "required": []any{"boardInvolved"}, "title": "Board Involvement?", "type": "object"}, "type": "input"}, "escalate": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Escalate to CISO", "type": "task"}, "extract-iocs": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Extract IOCs", "next": map[string]any{"block-iocs": ""}, "schema": map[string]any{"properties": map[string]any{"iocs": map[string]any{"items": map[string]any{"type": "string"}, "title": "IOCs", "type": "array"}}, "title": "Extract IOCs", "type": "object"}, "type": "input"}, "mail-available": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Mail available", "next": map[string]any{"block-sender": "schemaKey == 'yes'", "extract-iocs": "schemaKey == 'yes'", "search-email-gateway": "schemaKey == 'no'"}, "schema": map[string]any{"oneOf": []any{map[string]any{"properties": map[string]any{"mail": map[string]any{"title": "Mail", "type": "string", "x-display": "textarea"}, "schemaKey": map[string]any{"const": "yes", "type": "string"}}, "required": []any{"mail"}, "title": "Yes"}, map[string]any{"properties": map[string]any{"schemaKey": map[string]any{"const": "no", "type": "string"}}, "title": "No"}}, "title": "Mail available", "type": "object"}, "type": "input"}, "search-email-gateway": map[string]any{"created": time.Date(2021, time.December, 12, 12, 12, 12, 12, time.UTC), "done": false, "name": "Search email gateway", "next": map[string]any{"extract-iocs": ""}, "type": "task"}}}}, "references": []any{map[string]any{"href": "https://www.leadmaximize.net/e-services/back-end", "name": "performance"}, map[string]any{"href": "http://www.corporateinteractive.name/rich", "name": "autumn"}, map[string]any{"href": "https://www.corporateintuitive.org/intuitive/platforms/integrate", "name": "suggest"}}, "schema": "{\n  \"definitions\": {},\n  \"$schema\": \"http://json-schema.org/draft-07/schema#\",\n  \"$id\": \"https://example.com/object1618746510.json\",\n  \"title\": \"Event\",\n  \"type\": \"object\",\n  \"required\": [\n    \"severity\",\n    \"description\",\n    \"tlp\"\n  ],\n  \"properties\": {\n    \"severity\": {\n      \"$id\": \"#root/severity\",\n      \"title\": \"Severity\",\n      \"type\": \"string\",\n      \"default\": \"Medium\",\n      \"nx-enum\": [\n        \"Low\",\n        \"Medium\",\n        \"High\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"Low\",\n          \"title\": \"Low\",\n          \"icon\": \"mdi-chevron-up\"\n        },\n        {\n          \"const\": \"Medium\",\n          \"title\": \"Medium\",\n          \"icon\": \"mdi-chevron-double-up\"\n        },\n        {\n          \"const\": \"High\",\n          \"title\": \"High\",\n          \"icon\": \"mdi-chevron-triple-up\"\n        }\n      ]\n    },\n    \"tlp\": {\n      \"$id\": \"#root/tlp\",\n      \"title\": \"TLP\",\n      \"type\": \"string\",\n      \"nx-enum\": [\n        \"White\",\n        \"Green\",\n        \"Amber\",\n        \"Red\"\n      ],\n      \"x-cols\": 6,\n      \"x-class\": \"pr-2\",\n      \"x-display\": \"icon\",\n      \"x-itemIcon\": \"icon\",\n      \"oneOf\": [\n        {\n          \"const\": \"White\",\n          \"title\": \"White\",\n          \"icon\": \"mdi-alpha-w\"\n        },\n        {\n          \"const\": \"Green\",\n          \"title\": \"Green\",\n          \"icon\": \"mdi-alpha-g\"\n        },\n        {\n          \"const\": \"Amber\",\n          \"title\": \"Amber\",\n          \"icon\": \"mdi-alpha-a\"\n        },\n        {\n          \"const\": \"Red\",\n          \"title\": \"Red\",\n          \"icon\": \"mdi-alpha-r\"\n        }\n      ]\n    },\n    \"description\": {\n      \"$id\": \"#root/description\",\n      \"title\": \"Description\",\n      \"type\": \"string\",\n      \"x-display\": \"textarea\",\n      \"x-class\": \"pr-2\"\n    }\n  }\n}\n", "status": "closed", "type": "incident"}, map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8125, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "name": "phishing from selenafadel@von.com detected", "owner": "demo", "references": []any{map[string]any{"href": "https://www.seniorleading-edge.name/users/efficient", "name": "recovery"}, map[string]any{"href": "http://www.dynamicseamless.com/clicks-and-mortar", "name": "force"}, map[string]any{"href": "http://www.leadscalable.biz/envisioneer", "name": "fund"}}, "schema": "{}", "status": "closed", "type": "alert"}}, "type": "alert"},
		},
	},

	{
		Name: "UnlinkTicket",
		Args: Args{Method: "Delete", URL: "/tickets/8126/tickets", Data: 8125},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"created": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "id": 8126, "modified": time.Date(2021, time.October, 2, 16, 4, 59, 78186000, time.UTC), "name": "Surfaceintroduce virus detected", "owner": "demo", "references": []any{map[string]any{"href": "http://www.centralworld-class.io/synthesize", "name": "university"}, map[string]any{"href": "https://www.futurevirtual.org/supply-chains/markets/sticky/iterate", "name": "goal"}, map[string]any{"href": "http://www.chiefsyndicate.io/action-items", "name": "unemployment"}}, "schema": "{}", "status": "closed", "type": "alert"},
		},
	},

	{
		Name: "ListTicketTypes",
		Args: Args{Method: "Get", URL: "/tickettypes"},
		Want: Want{
			Status: 200,
			Body:   []any{map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-alert", "id": "alert", "name": "Alerts"}, map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-radioactive", "id": "incident", "name": "Incidents"}, map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-fingerprint", "id": "investigation", "name": "Forensic Investigations"}, map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-target", "id": "hunt", "name": "Threat Hunting"}},
		},
	},

	{
		Name: "CreateTicketType",
		Args: Args{Method: "Post", URL: "/tickettypes", Data: map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-newspaper-variant-outline", "name": "TI Tickets"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-newspaper-variant-outline", "id": "ti-tickets", "name": "TI Tickets"},
		},
	},

	{
		Name: "GetTicketType",
		Args: Args{Method: "Get", URL: "/tickettypes/alert"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-alert", "id": "alert", "name": "Alerts"},
		},
	},

	{
		Name: "UpdateTicketType",
		Args: Args{Method: "Put", URL: "/tickettypes/alert", Data: map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-bell", "id": "alert", "name": "Alerts"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"default_playbooks": []any{}, "default_template": "default", "icon": "mdi-bell", "id": "alert", "name": "Alerts"},
		},
	},

	{
		Name: "DeleteTicketType",
		Args: Args{Method: "Delete", URL: "/tickettypes/alert"},
		Want: Want{
			Status: 204,
			Body:   nil,
		},
	},

	{
		Name: "ListUserData",
		Args: Args{Method: "Get", URL: "/userdata"},
		Want: Want{
			Status: 200,
			Body:   []any{map[string]any{"email": "bob@example.org", "id": "bob", "name": "Bob Bad"}},
		},
	},

	{
		Name: "GetUserData",
		Args: Args{Method: "Get", URL: "/userdata/bob"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"email": "bob@example.org", "id": "bob", "name": "Bob Bad"},
		},
	},

	{
		Name: "UpdateUserData",
		Args: Args{Method: "Put", URL: "/userdata/bob", Data: map[string]any{"blocked": false, "email": "bob@example.org", "name": "Bob Bad"}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"email": "bob@example.org", "id": "bob", "name": "Bob Bad"},
		},
	},

	{
		Name: "ListUsers",
		Args: Args{Method: "Get", URL: "/users"},
		Want: Want{
			Status: 200,
			Body:   []any{map[string]any{"apikey": false, "blocked": false, "id": "bob", "roles": []any{"admin"}}, map[string]any{"apikey": true, "blocked": false, "id": "script", "roles": []any{"engineer"}}},
		},
	},

	{
		Name: "CreateUser",
		Args: Args{Method: "Post", URL: "/users", Data: map[string]any{"apikey": true, "blocked": false, "id": "syncscript", "roles": []any{"analyst"}}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"blocked": false, "id": "syncscript", "roles": []any{"analyst"}, "secret": "v39bOuobnlEljfWzjAgoKzhmnh1xSMxH"},
		},
	},

	{
		Name: "GetUser",
		Args: Args{Method: "Get", URL: "/users/script"},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"apikey": true, "blocked": false, "id": "script", "roles": []any{"engineer"}},
		},
	},

	{
		Name: "UpdateUser",
		Args: Args{Method: "Put", URL: "/users/bob", Data: map[string]any{"apikey": false, "blocked": false, "id": "syncscript", "roles": []any{"analyst", "admin"}}},
		Want: Want{
			Status: 200,
			Body:   map[string]any{"apikey": false, "blocked": false, "id": "bob", "roles": []any{"analyst", "admin"}},
		},
	},

	{
		Name: "DeleteUser",
		Args: Args{Method: "Delete", URL: "/users/script"},
		Want: Want{
			Status: 204,
			Body:   nil,
		},
	},
}
